const { sequelize, DataTypes } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
    const Pessoa = sequelize.define('Pessoa',
        {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    nome: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    cpf: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    tel: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            is: /^\(\d{2}\)\s?\d{4,5}\-\d{4}$/  
        }
    },
    forca: {
        type: DataTypes.STRING,
        allowNull: false,
    },
},
{
    tableName: 'Pessoa',
    timestamps: false,
}
);

return Pessoa;

};
