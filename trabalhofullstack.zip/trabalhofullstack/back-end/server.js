const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');

const app = express();
const port = 8080;

app.use(express.json());

app.use(express.static('front-end'));

const validarCPF = (cpf) => {
    return /^\d{11}$/.test(cpf);
};



app.get('/', (req, res) => {
    res.send('Bem-vindo ao sistema de cadastro de Pessoa!');
});

app.post('/pessoa', (req, res) => {
    const { nome, cpf, tel, forca } = req.body;

    if (!nome || !cpf || !tel || !forca) {
        return res.status(400).json({ message: 'Nome, CPF e Telefone são obrigatórios' });
    }

    if (!validarCPF(cpf)) {
        return res.status(400).json({ message: 'CPF inválido' });
    }

    const cpfExistente = cadastroData.find(c => c.cpf === cpf);
    if (cpfExistente) {
        return res.status(409).json({ message: 'CPF já cadastrado' });
    }

    const novoCadastro = { nome, cpf, telefone };
    cadastroData.push(novoCadastro);

    res.status(201).json({ message: 'Cadastro realizado com sucesso', data: novoCadastro });
});

app.get('/pessoa/:cpf', (req, res) => {
    const { cpf } = req.params;

    const pessoa = pessoaData.find(c => c.cpf === cpf);

    if (pessoa) {
        res.json(pessoa);
    } else {
        res.status(404).send('Pessoa não encontrado');
    }
});

app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});