const express = require('express');
const PessoaController = require('./controllers/PessoaController');

const router = express.Router();

router.post('/Pessoa', PessoaController.createPessoa);
router.get('/Pessoa/cpf/:cpf', PessoaController.createCPF);
router.post('/Pessoa/tel/:tel', PessoaController.createTel);
router.get('/Pessoa', PessoaController.getAllPessoas);
router.get('/Pessoa', PessoaController.getPessoaById);
router.put('/Pessoa', PessoaController.updatePessoa);
router.delete('/Pessoa', PessoaController.deletePessoa);

module.exports = router;