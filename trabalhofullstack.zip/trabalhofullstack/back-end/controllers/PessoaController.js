const axios = require('axios');

const pessoaController = {
    async criarPessoa(req, res) {
        try {

            const { nome, cpf, tel, forca } = req.body;

            if (!nome || !cpf || !tel || !forca) {
                return res.status(400).json({ error: "Todos os campos são obrigatórios." });
            }

            const payload = {
                nome: nome,
                cpf: cpf,
                tel: tel
            };

            const response = await axios.post('http://localhost:8080/api/pessoa', payload);

            res.status(201).json(response.data);

    } catch (error) {
        if (error.response) {

            return res.status(error.response.status).json({ error: error.response.data });
        } else if (error.request) {

            return res.status(500).json({ error: "Nenhuma resposta do servidor." });
        } else {

            return res.status(500).json({ error: "Erro ao fazer a requisição." });
        }
    }
}
};

module.exports = pessoaController;