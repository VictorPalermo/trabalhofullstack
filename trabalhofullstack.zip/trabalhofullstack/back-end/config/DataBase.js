module.exports = {
  dialect: 'oracle',
  host: 'localhost', 
  port: 1521, 
  username: 'system', 
  password: '123', 
  database: 'xe', 
  logging: false,
  define: {
    timestamps: false,
    underscored: false,
  }
};
