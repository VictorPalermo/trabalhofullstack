document.getElementById('formPessoa').addEventListener('submit', async (event) =>{
    event.preventDefault();

    const nome = document.getElementById('nome').value;
    const cpf = document.getElementById('cpf').value;
    const tel = document.getElementById('tel').value;
    const forca = document.getElementById('forca').value;


    try {
        const response = await fetch('/pessoa',{
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ nome, cpf, tel, forca })
        });

        const result = await response.json();
        document.getElementById('message').innerText = 'Pessoa criada com sucesso!!';
        document.getElementById('formPessoa').reset();

    } catch (error) {
        console.error('Erro ao enviar formulário', error);
        document.getElementById('message').innerText = 'Erro na comunicação com o servidor';
    }

});